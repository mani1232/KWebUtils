package cc.worldmandia.kwebconverter

import kotlin.test.Test
import kotlin.test.assertEquals

class ComposeAppWebTest {

    @Test
    fun example() {
        assertEquals(3, 1 + 2)
    }
}