package cc.worldmandia.kwebconverter

enum class ParserType {
    JSON5,
    JSON,
    YAML,
    UNSUPPORTED
}